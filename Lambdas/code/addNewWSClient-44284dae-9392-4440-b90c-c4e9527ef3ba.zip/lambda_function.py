import json
import boto3
import base64

def lambda_handler(event, context):
    """
    Dodaje nowe połączenie dla gracza 
    Dodanie gracza do planszy i poinformowanie pozostałych jest w lambdzie OnWsJoinGame
    """
    try:
        email = event['queryStringParameters']['email']
        roomId = event['queryStringParameters']['roomId']
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('WebSocketClients')
        conn = event['requestContext']['connectionId']
        table.put_item(
                Item={
                    'email': email,
                    'connectionId' : conn,
                    'roomId': roomId
                }
            )
       
    except Exception as e:
        return { "statusCode": 400, "body": "Coś poszło nie tak" }
    return { "statusCode": 200, "body": "Na szczęście się udało!", }