import json
import boto3
import csv 

def lambda_handler(event, context):
    try: 
        s3 = boto3.client('s3')
        dynamodb = boto3.client('dynamodb')
        file = s3.get_object(Bucket='sudoku-multiplayer-cloud', Key='sudoku_light.csv')
        print(file)
        record_list = file['Body'].read().decode("utf-8").split("\n")
        print(record_list[0])
        firstrecord = True 

        csv_reader = csv.reader(record_list, delimiter=',', quotechar='"')
        i=0
        for row in csv_reader:
            if(firstrecord):
                firstrecord=False
                continue
            puzzle = row[0]
            solution = row[1]
            print(f"{i}:{puzzle},{solution}")
            if i<700:
                level=0
            elif i<1500:
                level=1
            else:
                level=2
            try:
                response = dynamodb.put_item(
                    TableName='GameBase',
                    Item={
                        'Id': {"N": str(i)},
                        'puzzle': {"S":puzzle},
                        'solution': {"S":solution},
                        'level': {"N":str(level)},
                    },
                    ConditionExpression = "attribute_not_exists(Id)")
            except:
                print(i, end="|")
            i = i+1
    except Exception as e:
        print(str(e))
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
