import json
import boto3
from datetime import datetime
import random

def lambda_handler(event, context):
    """
    Usuwa gniazdo WebSocket dla użytkownika
    """
    try:
        log_removing(event)
        dynamodb = boto3.resource('dynamodb')
        web_socket_table = dynamodb.Table('WebSocketClients')
        games_table = dynamodb.Table('Games')
        conn = event['requestContext']['connectionId']
        email, roomId = get_data(conn, web_socket_table )
        web_socket_table.delete_item(Key={'connectionId': conn})
        players = get_players(roomId, games_table)
        other_players = get_other_players_connections_id(players, email)
        res = remove_player_from_room(roomId, conn, email, players, games_table)
        apigatewaymanagementapi = boto3.client('apigatewaymanagementapi', endpoint_url = "https://" +  event["requestContext"]["domainName"] + "/" +  event["requestContext"]["stage"])   
        
        for player_connection_id in other_players: 
            apigatewaymanagementapi.post_to_connection(
                Data = json.dumps({"body": {"messageType":"PlayerLeftRoom", "email":email}}),
                ConnectionId = player_connection_id
            )

    except Exception as e:
        return { "statusCode": 400, "body": str(e)}
    return { "statusCode": 200, "body": "Disconnected."}
    
    
def get_players(roomId, table= None):
    """
    Pobiera graczy z danego pokoju
    roomId - id pokoju (gry) 
    table - tablica Games 
    """
    if not table:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Games')
    game = table.get_item(Key={'GameId': roomId})
    players = game['Item']['players']
    return players
    
    
def get_other_players_connections_id(players, email):
    """
    Pobiera connectionId pozostałych graczy
    players - wszyscy gracze w danej grze ze swoimi connectionId (lista dwuelementowych list)
    """
    result = []
    for player in players:
        if player[0] != email:
            result.append(player[1])
    return result
    

def remove_player_from_room(roomId, connectionId, email, players, table=None):
    """
    Usuwa użytkownika z gry (jego email z games)
    roomId - id pokoju 
    connectionId - connectionId gracza, ktory ma byc usuniety 
    players - aktualna lista graczy w pokoju 
    table - baza Games 
    """
    if not table: 
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Games')
    new_players = []
    for player in players: 
        if player[0] != email:
            new_players.append(player)
    response = table.update_item(
            Key={'GameId': roomId},
            UpdateExpression=f"SET players = :newPlayers",  
            ExpressionAttributeValues={  
                ":newPlayers": new_players
            },
            ReturnValues="ALL_NEW"
        )
    return response
    
def log_removing(event):
    dynamodb = boto3.resource('dynamodb')
    log_table = dynamodb.Table('RemoveLog')
    log_table.put_item(Item={
                'logId': f"{random.randrange(10**7, 10**8)}",
                'eventKeys': str(event.keys()),
                'event' : str(event),
                "time" : str(datetime.now())
            },)
            
def get_data(connectionId, table=None):
    """
    Zwraca email i roomId dla podanego connectionId
    """
    if not table:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('WebSocketClients')
    res = table.get_item(Key={'connectionId': connectionId})
    return res['Item']['email'], res['Item']['roomId']