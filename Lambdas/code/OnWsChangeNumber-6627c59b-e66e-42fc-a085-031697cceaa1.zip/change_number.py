from sudoku_multiplayer.board import Board
from dynamodb_stuff import get_board, get_games_table, update_board

def change_number(roomId, row, column, value):
    """
    w pokoju o id roomId 
    zmienia zawartosc pola o indeksie (row,column) na wartość value 
    zwraca aktualne pola sudoku (fields) i informację o wygranej (win)
    """
    table = get_games_table()
    board = get_board(roomId, table)
    board.insert_field(row,column,value)
    win = board.is_game_correct()
    fields = update_board(roomId, board, table)
    return fields, win