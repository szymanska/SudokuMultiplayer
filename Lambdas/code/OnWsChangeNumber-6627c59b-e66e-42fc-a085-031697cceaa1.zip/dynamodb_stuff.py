from sudoku_multiplayer.board import Board
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')


def get_games_table():
    """
    pobiera tabelę Games
    """
    table = dynamodb.Table('Games')
    return table
    
    
def update_board(roomId, board, table=None):
    """
    przyjmuje numer pokoju i obiekt Board z aktualnym sudoku 
    zwraca aktualne (po update) fields z bazy
    """
    if not table:
        table = get_games_table()
    try:
        response = table.update_item(
            Key={'GameId': roomId},
            UpdateExpression=f"SET sudoku=:sudoku",  
            ExpressionAttributeValues={  
                ":sudoku": board.fields
            },
            ReturnValues="ALL_NEW"
        )
    except ClientError as e:
        if e.response['Error']['Code'] == "ConditionalCheckFailedException":
            print(e.response['Error']['Message'])
        else:
            raise
    else:
        return response['Attributes']['sudoku']
 
       
def get_board(roomId, table=None):
    """
    zwraca obiekt Board utworzony na podstawie sudoku z pokoju o id = roomId
    """
    if not table:
        table = get_games_table()
    try:
        board = Board(table.get_item(Key={'GameId': roomId})['Item']['sudoku'])
    except ClientError as e:
        if e.response['Error']['Code'] == "ConditionalCheckFailedException":
            print(e.response['Error']['Message'])
        else:
            raise
    else:
        return board

    
def get_all_players_connections_id(roomId):
    """
    Pobiera connectionIds innych graczy
    """
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Games')
    game = table.get_item(Key={'GameId': roomId})
    players = game['Item']['players']
    result = []
    for player in players:
        result.append(player[1])
    return result