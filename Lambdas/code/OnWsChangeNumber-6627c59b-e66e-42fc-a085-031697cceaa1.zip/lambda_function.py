import json
import random
import boto3
from sudoku_multiplayer.board import Board
from change_number import change_number
from dynamodb_stuff import get_all_players_connections_id
import decimal
from datetime import datetime, timedelta


class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return int(o)
        return super(DecimalEncoder, self).default(o)
        

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        body = body['message']
        
        roomId = body['roomId']
        row = body['row']
        column = body['column']
        value = body['value']
        
        fields, win = change_number(roomId, row, column, value)
        
        apigatewaymanagementapi = boto3.client('apigatewaymanagementapi', endpoint_url = "https://" +  event["requestContext"]["domainName"] + "/" +  event["requestContext"]["stage"]) 
        
        senderConnectionId = event['requestContext']['connectionId']
        
        if fields[row][column]['value'] != value:
            data = json.dumps({"body":{"messageType":"NumberChangedError", "message": "Incorrect value"}})
            try:
                apigatewaymanagementapi.post_to_connection(
                    Data = data ,
                    ConnectionId = senderConnectionId
                )
            except:
                #connection nie ma
                pass
        else:
            messageType = "NumberChanged"
            if win == True:
                messageType = "GameIsWon"
                
            data = json.dumps({"body":{"messageType": messageType, "row": row, "column": column, "value": value}})
            try:
                apigatewaymanagementapi.post_to_connection(
                    Data = data ,
                    ConnectionId = senderConnectionId
                )
            except:
                #connection nie ma
                pass
            
            other_players = get_all_players_connections_id(roomId)
            other_players.remove(senderConnectionId)

            for player_connection_id in other_players: 
                try:
                    apigatewaymanagementapi.post_to_connection(
                        Data = data ,
                        ConnectionId = player_connection_id
                    )
                except:
                    #connection nie ma
                    pass
            
    except Exception as e: 
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('errors')
        body = json.loads(event['body'])
        table.put_item(Item={
                'errorID': random.randrange(10**7, 10**8),
                'eventKeys': str(event.keys()),
                'event' : str(event),
                'message' : str(e),
                'body' : str(body.keys()),
                "time" : str(datetime.now())
            },)
        return { 'statusCode': 400, "body": str(e)}
    return { 'statusCode': 200,'body': "success" }

