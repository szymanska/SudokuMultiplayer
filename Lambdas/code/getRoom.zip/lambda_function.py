import boto3
import json
from botocore.exceptions import ClientError
from pprint import pprint

def enter_room(roomId, email, connectionId):
    """
    Dodaje użytkownika do gry 
    """
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Games')
    
    try:
        response = table.get_item(Key={'GameId': roomId})
        response = table.update_item(
            Key={'GameId': roomId},
            UpdateExpression=f"SET players = list_append(players, :newUser)",  
            ExpressionAttributeValues={  
                ":newUser": [[email,connectionId]]
            },
            ReturnValues="ALL_NEW"
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        return response['Attributes']


def lambda_handler(event, context):
    """
    Przyjmuje roomId, email i connectionId,
    Dodaje użytkownika do gry w tabeli Games 
    Zwraca wpis z tabeli Games
    """
    data = event['body']
    if type(data) == str:
        data = json.loads(data)
    roomId = data['roomId']
    email = data['email']
    connectionId = data['connectionId']
    room = enter_room(roomId, email, connectionId)
    if room == None:
        return {'statusCode': 400,'body': room}
    return {'statusCode': 200,'body': {
        'room': room,
        'messageType' : "JoinResult"
    }}