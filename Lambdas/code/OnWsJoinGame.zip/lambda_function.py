import json
import boto3
import random

def lambda_handler(event, context):
    """
    Wysyła wszystkim innym informacje ze dołączył
    Wysyła graczowi listę pól
    """
    try:
        body = json.loads(event['body'])
        body = body['message']
        email = body['email']
        roomId = body['roomId']
        connectionId = event['requestContext']['connectionId']
        lambda_service = boto3.client('lambda')
        room_response = get_room_lambda(lambda_service,roomId, email, connectionId)
        other_players = get_other_players_connections_id(roomId, email)
        
        apigatewaymanagementapi = boto3.client('apigatewaymanagementapi', endpoint_url = "https://" +  event["requestContext"]["domainName"] + "/" +  event["requestContext"]["stage"])   
        apigatewaymanagementapi.post_to_connection(
            Data=room_response,
            ConnectionId=connectionId
        )
        
        for player_connection_id in other_players: 
            apigatewaymanagementapi.post_to_connection(
                Data = json.dumps({"body": {"messageType":"NewPlayerAnnounce", "email":email}}),
                ConnectionId = player_connection_id
            )
    except Exception as e: 
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('errors')
        body = json.loads(event['body'])
        table.put_item(Item={
                'errorID': random.randrange(10**7, 10**8),
                'eventKeys': str(event.keys()),
                'event' : str(event),
                'message' : str(e),
                'body' : str(body.keys())
            },)
        return { 'statusCode': 400, "body":str(e)}
    return { 'statusCode': 200,'body': "udało się" }



def get_room_lambda(lambda_service, roomId, email, connectionId):
    """
    Dodaje gracza do planszy (wywołuje lambdę za to odpowiedzialną)
    """
    response = lambda_service.invoke(
        FunctionName='getRoom',
        LogType="Tail",
        Payload=(json.dumps({"body":{
            "roomId": roomId,
            "email":email,
            "connectionId":connectionId
       }}))
    )
    res = response['Payload'].read().decode("utf-8")
    return res


def get_other_players_connections_id(roomId, email):
    """
    Pobiera connectionIds innych graczy
    """
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Games')
    game = table.get_item(Key={'GameId': roomId})
    players = game['Item']['players']
    result = []
    for player in players:
        if player[0] != email:
            result.append(player[1])
    return result