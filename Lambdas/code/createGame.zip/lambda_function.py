import json
import boto3
from boto3.dynamodb.conditions import Attr
from botocore.exceptions import ClientError
from datetime import date, datetime
import random

from sudoku_multiplayer.board import Board

def generate_game_id():
    num = random.randrange(10**7, 10**8)
    return str(num)
    
def create_sudoku(lvl, type):
    levels = {'EASY' : 0, 'NORMAL' : 1, 'HARD' : 2}
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('GameBase')
    response = table.scan(
      FilterExpression=Attr('level').eq(levels[lvl])
    )['Items']
    
    num = random.randrange(0, len(response))
    # ToDo pobrać z bazy danych
    #puzzle = "004300209005009001070060043006002087190007400050083000600000105003508690042910300"
    #solution = "864371259325849761971265843436192587198657432257483916689734125713528694542916378"
    board = Board.from_origin(response[num]['puzzle'], response[num]['solution'])
    return board.fields.tolist()
    
    
def put_sudoku_db(table, data, fields):
    roomId = generate_game_id()
    try:
        response = table.put_item(
            Item={
                'GameId': roomId,
                'lvl': data['lvl'],
                'type': data['type'],
                'sudoku': fields,
                'date': str(datetime.now()),
                'players': []
            },
            ConditionExpression = "attribute_not_exists(GameId)"
        )
    except ClientError as e:  
        if e.response['Error']['Code']=='ConditionalCheckFailedException':
            # existing id error, try again
            return put_sudoku_db(table, data, sudoku)
    
    return roomId, response

def lambda_handler(event, context):
    try:
        data = event['body']
        if type(data) == str:
            data = json.loads(data)
    
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Games')
        
        fields = create_sudoku(data['lvl'], data['type'])
        roomId, response = put_sudoku_db(table, data, fields)

        output_data = {
            'roomId': roomId,
            'board': fields
        }
        
        status = 200
        body = json.dumps(output_data)     #output_data.json()
        
    except Exception as e:
        status = 400
        body = str(e)
    except:
        status = 400
        body = 'Unknown error!'
    
    return  {
        'statusCode': status,
        'headers': {
            'Access-Control-Allow-Origin': "*",
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Methods': "OPTIONS,POST,GET",
            'Access-Control-Allow-Credentials' : True
        },
        'body': body
    }
