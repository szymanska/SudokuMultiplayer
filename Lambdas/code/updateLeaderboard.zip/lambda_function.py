import json
import boto3
import random
from datetime import datetime
from update_leaderboard import update_leaderboard

def lambda_handler(event, context):
    try:
        data = json.loads(event['body'])
        
        roomId = data['roomId']
        
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('Games')
        response = table.get_item(Key={'GameId' : roomId})['Item']
        
        lvl = response['lvl']
        type = response['type']
        minute = str(data['time']['minute'])
        if data['time']['second'] > 9:
            second = str(data['time']['second']) 
        else:
            second = '0' + str(data['time']['second'])
        time = minute + "." + second      
        update_leaderboard(lvl, type, time)
        
    except Exception as e: 
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('errors')
        body = json.loads(event['body'])
        table.put_item(Item={
                'errorID': random.randrange(10**7, 10**8),
                'eventKeys': str(event.keys()),
                'event' : str(event),
                'message' : str(e),
                'body' : str(body.keys()),
                "time" : str(datetime.now())
            })
        return { 
            'statusCode': 400, 
            'headers': {
                'Access-Control-Allow-Origin': "*",
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': "OPTIONS,POST,GET",
                'Access-Control-Allow-Credentials' : True
            },
            "body": str(e)
        }
        
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': "*",
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Methods': "OPTIONS,POST,GET",
            'Access-Control-Allow-Credentials' : True
        },
        'body': json.dumps('Leaderboard updated')
    }
