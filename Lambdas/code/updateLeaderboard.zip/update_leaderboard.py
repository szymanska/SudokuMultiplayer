import boto3

def update_leaderboard(lvl, type, game_time):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Leaderboard')
    try:
        response = table.get_item(Key={'level': lvl, 'type': type})['Item']
    except:
        response = None
    
    if response == None:
        table.put_item(Item={
            'level' : lvl,
            'type' : type,
            'time' : game_time
        })
    else:
        if str(response['time']) > game_time:
            table.update_item(
                Key={
                    'level': lvl,
                    'type': type
                },
                UpdateExpression="set #tm=:t",
                ExpressionAttributeNames={"#tm": "time"},
                ExpressionAttributeValues={
                    ':t': game_time
                },
                ReturnValues="NONE"
            )